import tkinter as tk
import os
root = tk.Tk()


root.configure(bg="#000000")


def goToSleep():
    os.system("i3lock -c 000000 -u && pkill python3 && systemctl suspend")


def goToWake():
    os.system("reboot")


def goToDie():
    os.system("shutdown -h now")

def close():
    os.system("pkill python3")


sleep = tk.Button(text="Sleep", width=50, height=10, command=goToSleep)
reboot = tk.Button(text="Reboot", width=50, height=10, command=goToWake)
shutdown = tk.Button(text="Shutdown", width=50, height=10, command=goToDie)
close = tk.Button(text="Close", width=50, height=10, command=close)

sleep.pack()
reboot.pack()
shutdown.pack()
close.pack()

root.mainloop()
